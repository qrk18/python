def run(path):
    freq={}
    fin=open(path)
    for line in fin:
        words=line.lower().strip().split(' ');
        for word in words:
            if word in freq:
                freq[word]=freq[word]+1
            else:
                freq[word]=1

    print (freq)
    return(max(freq, key=freq.get))
    
    fin.close()

print(run('textfile'))
    